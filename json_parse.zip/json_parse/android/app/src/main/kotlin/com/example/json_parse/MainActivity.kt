package com.example.json_parse

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
